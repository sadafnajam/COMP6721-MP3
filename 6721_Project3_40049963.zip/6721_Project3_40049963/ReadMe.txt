Use the following command to execute the main program

python3 main.py

Experiments, including the 4th language "Afrikaans" and implementing the trigram model using the scikit-learn


python3 main-additional.py


