import re
import math
import os
# from collections import Counter
def merge_files(_file_names ,ftype='EN',onlyAlpha = True):
    lines = []
    _dir = "mergedFiles/"
    if not os.path.exists(_dir):
        os.makedirs(_dir)
    if ftype =='FR':
        _file = open(_dir + 'trainFR.txt', "w")
    elif ftype =='EN':
        _file = open(_dir + 'trainEN.txt', "w")
    else:
        _file = open(_dir + 'trainGR.txt', "w")
    for fname in _file_names:
        with open(fname,encoding="utf8", errors='ignore') as infile:
        # with open(fname) as infile:
            completeString = infile.read()
            completeString = completeString.lower()
            if(onlyAlpha == True):
                completeString = re.sub(" \d+", '', completeString)
                completeString = re.sub('[^A-Za-z]+', '', completeString)
            lines = lines + [completeString]
            _file.write(completeString)
    return lines

def generate_corpus(_model_names, _file_names, ltype, _smoothing):
    _data  = ""
    for _item in merge_files(_file_names, ltype):
        _data = _data + _item
    corpus = list(_data)
    # unigrams_model = [(corpus[i]) for i in range(0,len(corpus)-1)]
    # bigrams_model = [(corpus[i],corpus[i+1]) for i in range(0,len(corpus)-1)]
    # _bgramCount = Counter(unigrams_model)
    # _unigramCount = Counter(bigrams_model)
    # print(len(bigrams_model))
    # print(len(Counter(unigrams_model)))
    # print(len(Counter(bigrams_model)))
    _bgramCount = {}
    _unigramCount = {}
    _biagram_list = []
    # print(len(corpus))
    for i in range(len(_data)):
        if i < len(_data) - 1:
            if (_data[i], _data[i+1]) in _bgramCount:
                _bgramCount[(_data[i], _data[i + 1])] += 1
            else:
                _biagram_list.append((_data[i], _data[i + 1]))
                _bgramCount[(_data[i], _data[i + 1])] = 1
        if _data[i] in _unigramCount:
            _unigramCount[_data[i]] += 1
        else:
            _unigramCount[_data[i]] = 1
    # print(_unigramCount)
    # print(_unigramCount.sort())
    # print(_bgramCount)
    # print(_biagram_list)
    _biagram_list = sorted(_biagram_list,key=sortKey)
    _biagram_list = sorted(_biagram_list, key=sortVal)
    uni_gram_model = generate_unigramProb(_model_names[0],_unigramCount,len(corpus), _smoothing)
    bi_gram_model = generate_bigramProb(_model_names[1],_biagram_list, _unigramCount, _bgramCount, _smoothing)
    # if ltype == 'EN':
    #     print("count : "+ str(len(corpus)))
    #     print('unigram')
    #     print(_unigramCount)
    #     print('bi gram, ')
    #     print(_bgramCount)
    return uni_gram_model, bi_gram_model

def sortKey(item):
    return item[0]
def sortVal(item):
    return item[1]
def probable_of_language(uni_en_model,bi_en_model,uni_fr_model,bi_fr_model, uni_ot_model,bi_ot_model, _smoothing):
    sentences = get_sentecnces("test_sentences30.txt")
    if sentences is not None:
        for idx,sentence in enumerate(sentences):
            print(sentence)
            _dir = "output/"
            if not os.path.exists(_dir):
                os.makedirs(_dir)
            _fname = _dir+"out"+str(idx+1)+".txt"
            _file = open(_fname,"w")
            _file.write(sentence +'\n')
            sentence = sentence.lower()
            sentence = re.sub(" \d+", '', sentence)
            sentence = re.sub('[^A-Za-z]+', '', sentence)
            _corpus = list(sentence)
            _sentence_en_uni = [(_corpus[i]) for i in range(0,len(_corpus))]
            _sentence_en_bi = [(_corpus[i],_corpus[i+1]) for i in range(0,len(_corpus)-1)]
            _file.write('UNIGRAM'+' MODEL:'+'\n')
            print('UNIGRAM'+' MODEL:'+'\n')
            classification_result(_file, _sentence_en_uni, uni_fr_model,uni_en_model,uni_ot_model, 'unigram', _smoothing)
            # _result_en = 0
            # _result_fn = 0
            # for _word in _sentence_en_uni:
            #     _file.write('UNIGRAM: ' + _word + '\n')
            #     _file.write('FRENCH: P('+ _word +') = '+ str(float(uni_fr_model.get(_word)))+' ==> log prob of sentence so far:' + str(float(uni_fr_model.get(_word))) + '\n\r')
            #     _file.write('ENGLISH: P('+ _word + ') = '+ str(float(uni_en_model.get(_word))) +'==> log prob of sentence so far: '+ str(float(uni_en_model.get(_word))) + '\n\r')
            #     if uni_en_model.get(_word) !=0:
            #         _result_en += uni_en_model.get(_word)
            #     if uni_fr_model.get(_word) !=0:
            #         _result_fn += uni_fr_model.get(_word)
            # if _result_en > _result_fn:
            #     print('According to the unigram model, the sentence is in English')
            #     _file.write('According to the unigram model, the sentence is in English' + '\n')
            # elif _result_en < _result_fn:
            #     print('According to the unigram model, the sentence is in French')
            #     _file.write('According to the unigram model, the sentence is in French' + '\n')
            # else:
            #     print('Probably is difficult to identify')
            #     _file.write('Probably is difficult to identify' + '\n')
            _file.write('\n')
            print('------------------------------------------------------------------------------------------------------')
            _file.write('BIGRAM'+' MODEL:'+'\n')
            print('\n')
            print('BIGRAM'+' MODEL:'+'\n')
            classification_result(_file, _sentence_en_bi, bi_fr_model,bi_en_model,bi_ot_model, 'bigram', _smoothing)
            # _result_bi_en = 0
            # _result_bi_fn = 0
            # for _word in _sentence_en_bi:
            #     _file.write('BIGRAM: ' + str(_word)+ '\n\r')
            #     _file.write('FRENCH: P('+ _word[1] + '|' + _word[0] +') = '+ str(float(bi_fr_model.get(_word)))+' ==> log prob of sentence so far:' +str(float( bi_fr_model.get(_word))) + '\n\r')
            #     _file.write('ENGLISH: P('+ _word[1] + '|' + _word[0] +') = '+ str(float(bi_en_model.get(_word))) +'==> log prob of sentence so far: '+ str(float(bi_en_model.get(_word))) + '\n\r')
            #     if bi_en_model.get(_word) !=0:
            #         _result_bi_en += bi_en_model.get(_word)
            #     if bi_fr_model.get(_word) !=0:
            #         _result_bi_fn += bi_fr_model.get(_word)
            # if _result_bi_en > _result_bi_fn:
            #     print('According to the bigram model, the sentence is in English')
            #     _file.write('According to the bigram model, the sentence is in English' + '\n')
            # elif _result_bi_en < _result_bi_fn:
            #     print('According to the bigram model, the sentence is in French')
            #     _file.write('According to the bigram model, the sentence is in French' + '\n')
            # else:
            #     print('Probably is difficult to identify')
            #     _file.write('Probably is difficult to identify' + '\n')
def classification_result(_file, _sentence_ngram_type, fr_model, en_model, ot_model, ngram_type, _smoothing):
    _result_en = 0
    _result_fn = 0
    _result_ot = 0
    for _word in _sentence_ngram_type:
        if ngram_type == 'bigram':
            _gram = (_word[1] + '|' + _word[0])
            _file.write(ngram_type.upper()+': ' + str(_word[0] + _word[1])+ '\n\r')
            print(ngram_type.upper()+': ' + str(_word[0] + _word[1])+ '\n\r')
        else:
            _gram = _word
            _file.write(ngram_type.upper()+': ' + str(_word)+ '\n\r')
            print(ngram_type.upper()+': ' + str(_word)+ '\n\r')
        if fr_model.get(_word) is None:
            fr_model[_word] = _smoothing
        if en_model.get(_word) is None:
            en_model[_word] = _smoothing
        if ot_model.get(_word) is None:
            ot_model[_word] = _smoothing
        if en_model.get(_word) !=0:
            # print(_word)
            # print(_result_en)
            # print(math.log10(en_model.get(_word)))
            _result_en += math.log10(en_model.get(_word))
        if fr_model.get(_word) !=0:
            _result_fn += math.log10(fr_model.get(_word))
        if ot_model.get(_word) !=0:
            _result_ot += math.log10(ot_model.get(_word))
        _file.write('FRENCH: P('+_gram +') = '+ str(float(fr_model.get(_word)))+' ==> log prob of sentence so far: ' +str(float(_result_fn)) + '\n\r')
        _file.write('ENGLISH: P('+ _gram +') = '+ str(float(en_model.get(_word))) +' ==> log prob of sentence so far: '+ str(float(_result_en)) + '\n\r')
        _file.write('GERMAN: P('+ _gram +') = '+ str(float(ot_model.get(_word))) +' ==> log prob of sentence so far: '+ str(float(_result_ot)) + '\n\r')
        _file.write('\n')
        print('FRENCH: P('+_gram +') = '+ str(float(fr_model.get(_word)))+' ==> log prob of sentence so far: ' +str(float(_result_fn)) + '\n\r')
        print('ENGLISH: P('+ _gram +') = '+ str(float(en_model.get(_word))) +' ==> log prob of sentence so far: '+ str(float(_result_en)) + '\n\r')
        print('GERMAN: P('+ _gram +') = '+ str(float(ot_model.get(_word))) +' ==> log prob of sentence so far: '+ str(float(_result_ot)) + '\n\r')

        # if _word == 'z' and ngram_type == 'unigram':
        #     print("=====================================================================================================")
        #     print(_word)
        #     print(math.log10(ot_model.get(_word)))
    # _file('\n')
    # print("Probability ENGLISH:\t" + str(_result_en) + "\n")
    # print("Probability FRENCH:\t" + str(_result_fn) + "\n")
    # print("Probability GERMAN:\t" + str(_result_ot) + "\n")
    if _result_en > _result_fn and  _result_en > _result_ot:
        print('According to the '+ngram_type+' model, the sentence is in English'+ '\n')
        _file.write('According to the '+ngram_type+' model, the sentence is in English' + '\n')
    elif _result_fn > _result_en and  _result_fn > _result_ot:
        print('According to the '+ngram_type+' model, the sentence is in French'+ '\n')
        _file.write('According to the '+ngram_type+' model, the sentence is in French' + '\n')
    elif _result_ot > _result_en and  _result_ot > _result_fn:
        print('According to the '+ngram_type+' model, the sentence is in GERMAN'+ '\n')
        _file.write('According to the '+ngram_type+' model, the sentence is in GERMAN' + '\n')
    else:
        print('Probably is difficult to identify')
        _file.write('Probably is difficult to identify' + '\n')
    print('===============================================================================================================')

def generate_unigramProb(fname,_unigramCount, totalCharCount, _smoothing):
    unigram = sorted(_unigramCount.items() , key=lambda t : t[0])
    prob_list = {}
    _dir = "models/"
    if not os.path.exists(_dir):
        os.makedirs(_dir)
    file = open(_dir+fname, 'w')
    for _val in unigram:
        _val = _val[0]
        prob_list[_val] = _unigramCount.get(_val)/totalCharCount
        # a -> c(a)/total(all)
        # print(_unigramCount.get(_val))
        # Unsmoothed
        # _prob = _unigramCount.get(_val)/totalCharCount
        # smoothed
        _prob = (_unigramCount.get(_val) + _smoothing)/ (totalCharCount + (_smoothing * len(_unigramCount)))
        # print(len(_unigramCount))
        # print(len(unigram))
        # print(_val)
        # print((_unigramCount.get(_val)))
        # print(totalCharCount)
        # print(len(unigram))
        # print(_prob)
        file.write(str('('+_val+')') + '=' + str(prob_list[_val]) + '\n')
    return prob_list

def get_sentecnces(fname):
    with open(fname) as file:
        _sentences = file.readlines()
        _sentences[len(_sentences) - 1] += "\n"
        # print(_sentences)
        return _sentences
    return None

def generate_bigramProb(fname,bigrams_model, _unigramCount, _bgramCount, _smoothing):
    prob_list = {}
    for _bigram in bigrams_model:
        char1 = _bigram[0]
        char2 = _bigram[1]
        #   wh -> (h|w) = c(wh)/c(w)
        #   _eq_up = (_bgramCount.get(_bigram) + 0.5
        #   _eq_down = (_unigramCount.get(char1) + len(_unigramCount))
        #   prob_list[_bigram] = (_eq_up/_eq_down)
        #   with smothing 0.5
        #   wh -> (h|w) = c(wh) + 0.5/c(w) + 26
        # Smoothed
        prob_list[_bigram] = (_bgramCount.get(_bigram) + _smoothing)/(_unigramCount.get(char1) + (_smoothing*len(_unigramCount)))
        # with out smoothing
        # prob_list[_bigram] = (_bgramCount.get(_bigram))/(_unigramCount.get(char1))
    _dir = "models/"
    if not os.path.exists(_dir):
        os.makedirs(_dir)
    file = open(_dir+fname, 'w')
    for _bg in bigrams_model:
		# file.write(str(_bg) + ', ' + str(_bgramCount[_bg])
				#    + ' : ' + str(prob_list[_bg]) + '\n')
        file.write(str('('+_bg[0] + '|'+_bg[1]+')') + '=' + str(prob_list[_bg]) + '\n')
        # print(str(_bg[1] + '|'+_bg[0]) + '=' + str(prob_list[_bg]) + '\n')
    return prob_list

def init():
    # print("init")
    _dir = 'TrainingCorpus'
    english_lang = [_dir+"/en-moby-dick.txt",_dir+"/en-the-little-prince.txt"]
    french_lang = [_dir+"/fr-vingt-mille-lieues-sous-les-mers.txt",_dir+"/fr-le-petit-prince.txt"]
    german_lang = [_dir+"/Buddenbrooks.txt",_dir+"/Kritik-der-reinen-Vernunft.txt"]
    smoothingVal = 0.5
    # smoothingVal = 0
    # smoothingVal = 1
    uni_gram_en_model, bi_gram_en_model = generate_corpus(['unigramEN.txt', 'bigramEN.txt'],english_lang, 'EN', smoothingVal)
    uni_gram_fr_model, bi_gram_fr_model = generate_corpus(['unigramFR.txt', 'bigramFR.txt'],french_lang, 'FR', smoothingVal)
    uni_gram_ot_model, bi_gram_ot_model = generate_corpus(['unigramGR.txt', 'bigramGR.txt'],german_lang, 'GER', smoothingVal)
    probable_of_language(uni_gram_en_model, bi_gram_en_model,uni_gram_fr_model, bi_gram_fr_model, uni_gram_ot_model, bi_gram_ot_model, smoothingVal)
    # generate_corpus(['unigramFR.txt', 'bigramFR.txt'],french_lang)

if __name__ == "__main__":
    init()
